#!/usr/bin/env python3
"""Gate de humo del servidor, contra los datos reales de ``data/raw``.

Es el criterio objetivo de "anda" para el porteo automatizado
(``scripts/autonomia/port_loop.py``): un ítem del PORT_PLAN se marca hecho sólo
si sus checks pasan acá.

Dos decisiones que importan:

1. **Habla sólo HTTP** y arranca el servidor con ``python -m server``. No importa
   ``server.app`` ni conoce su implementación. Por eso sobrevive al refactor de
   §1 (http.server -> FastAPI): si el gate importara ``app.py`` se rompería justo
   en el ítem que tiene que verificar.
2. **Los checks de lectura van contra el ``data/raw`` real** (210 capturas / 415
   nodos), que es lo único que detecta la trampa §5.1 del plan (el servidor
   mostraba 1 captura porque corría con el raw_root viejo). Los checks que
   escriben van contra un sandbox temporal: el gate nunca modifica el dataset.

Uso
---
    python server/smoke_test.py --list
    python server/smoke_test.py                     # todos
    python server/smoke_test.py --only base         # por prefijo de id
    python server/smoke_test.py --only capturas.pick --json out.json

Código de salida 0 si todos los checks seleccionados pasan, 1 si alguno falla,
2 si el servidor no arrancó.

Para agregar un check nuevo: decorar una función con ``@check("<item>.<nombre>",
"<qué prueba>", mode=...)`` y usar ``ctx.get`` / ``ctx.post``. Nada más; el
registro se descubre solo.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

REPO = Path(__file__).resolve().parents[4]          # igual que app.py:374, no re-derivar
PYTHON_ROOT = Path(__file__).resolve().parents[1]   # <repo>/src/interfaces/python
RAW_ROOT = REPO / "data" / "raw"
# Los logs del gate viven fuera del submódulo y están gitignorados: son evidencia
# para depurar, no código. Sin esto había que adivinar por qué falló un check.
LOG_DIR = REPO / "scripts" / "autonomia" / "state" / "gate"

# Cotas del dataset real (PORT_PLAN §0). Son mínimos, no igualdades: el dataset
# crece cuando se ingesta. Detectan el caso "el servidor ve 1 captura".
MIN_CAPTURES = 200
MIN_NODES = 400


# ── Registro de checks ────────────────────────────────────────────────────────
RUN_LOG: list[str] = []


def rec(msg: str, echo: bool = False) -> None:
    """Registra una línea con marca de tiempo. Todo queda; nada se adivina."""
    line = f"{time.strftime('%H:%M:%S')} {msg}"
    RUN_LOG.append(line)
    if echo:
        print(line, flush=True)


@dataclass
class Ctx:
    base_url: str
    raw_root: Path
    sandbox: bool = False

    def _do(self, req: urllib.request.Request, verb: str, path: str,
            timeout_s: float) -> tuple[int, bytes, dict]:
        """Un solo camino para todos los pedidos, así todos quedan registrados
        igual — incluido el caso que más importa: el que se cuelga."""
        started = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=timeout_s) as r:
                body, code, headers = r.read(), r.status, dict(r.headers)
        except urllib.error.HTTPError as exc:
            body, code, headers = exc.read(), exc.code, dict(exc.headers)
        except Exception as exc:
            dt = time.monotonic() - started
            rec(f"    {verb} {path} -> EXCEPCIÓN tras {dt:.1f}s: "
                f"{type(exc).__name__}: {exc}")
            raise
        dt = time.monotonic() - started
        rec(f"    {verb} {path} -> {code} {len(body)} B en {dt:.2f}s")
        return code, body, headers

    def get(self, path: str, timeout_s: float = 30.0) -> tuple[int, bytes, dict]:
        return self._do(urllib.request.Request(self.base_url + path),
                        "GET", path, timeout_s)

    def post(self, path: str, body: bytes = b"", headers: dict | None = None,
             timeout_s: float = 30.0) -> tuple[int, bytes, dict]:
        req = urllib.request.Request(self.base_url + path, data=body, method="POST")
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        return self._do(req, f"POST[{len(body)}B]", path, timeout_s)

    def options(self, path: str, timeout_s: float = 30.0) -> tuple[int, dict]:
        req = urllib.request.Request(self.base_url + path, method="OPTIONS")
        req.add_header("Origin", "http://192.168.4.1")
        req.add_header("Access-Control-Request-Method", "POST")
        code, _, headers = self._do(req, "OPTIONS", path, timeout_s)
        return code, headers

    def json_get(self, path: str) -> dict:
        code, body, _ = self.get(path)
        if code != 200:
            raise AssertionError(f"GET {path} -> {code}")
        return json.loads(body.decode("utf-8", "replace"))


@dataclass
class Check:
    cid: str
    desc: str
    mode: str            # "read" (raw real) | "sandbox" (dirs temporales)
    fn: Callable[[Ctx], None]


REGISTRY: list[Check] = []


def check(cid: str, desc: str, mode: str = "read"):
    def deco(fn):
        REGISTRY.append(Check(cid, desc, mode, fn))
        return fn
    return deco


# ── Checks base (deben pasar siempre, antes y después del refactor) ───────────
@check("base.health", "GET /health responde 200")
def _health(ctx: Ctx) -> None:
    code, _, _ = ctx.get("/health")
    assert code == 200, f"/health -> {code}"


@check("base.index", "GET / devuelve HTML de la web")
def _index(ctx: Ctx) -> None:
    code, body, _ = ctx.get("/")
    assert code == 200, f"/ -> {code}"
    assert b"<" in body and len(body) > 200, f"/ devolvió {len(body)} B sin HTML"


@check("base.dataset_completo", "el catálogo ve el dataset real, no un raw_root viejo")
def _dataset(ctx: Ctx) -> None:
    data = ctx.json_get("/api/dataset")
    caps = data.get("capture_count", 0)
    nodes = data.get("node_count", 0)
    assert caps >= MIN_CAPTURES, (
        f"capture_count={caps} < {MIN_CAPTURES}. Trampa §5.1: proceso viejo o raw_root "
        f"equivocado (dice {data.get('raw_root')!r})")
    assert nodes >= MIN_NODES, f"node_count={nodes} < {MIN_NODES}"
    assert data.get("folders"), "folders vacío"


@check("base.dataset_no_descarta", "ninguna carpeta del catálogo queda sin capturas listadas")
def _no_descarta(ctx: Ctx) -> None:
    # PORT_PLAN §5.5: discover_dataset descarta capturas sin par hammer+geo. El
    # catálogo NO debe hacerlo: una captura sin martillo se cataloga y se marca.
    data = ctx.json_get("/api/dataset")
    total = sum(len(f.get("captures", [])) for f in data["folders"])
    assert total == data["capture_count"], (
        f"suma de captures={total} != capture_count={data['capture_count']}")
    sin_hammer = sum(1 for f in data["folders"] for c in f["captures"]
                     if not c.get("has_hammer"))
    assert sin_hammer >= 0   # informativo; lo que importa es que estén listadas


@check("base.jobs", "GET /api/jobs devuelve la cola persistida")
def _jobs(ctx: Ctx) -> None:
    code, body, _ = ctx.get("/api/jobs")
    assert code == 200, f"/api/jobs -> {code}"
    json.loads(body.decode("utf-8", "replace"))


@check("base.cors_preflight", "OPTIONS /ingest trae las cabeceras CORS (§1)")
def _cors(ctx: Ctx) -> None:
    # Sin esto la SPA del ESP32 (otro origen) aborta en el preflight y en el
    # campo se ve como "servidor inalcanzable". PORT_PLAN §5.2.
    code, headers = ctx.options("/ingest")
    assert code in (200, 204), f"OPTIONS /ingest -> {code}"
    origin = headers.get("Access-Control-Allow-Origin")
    assert origin == "*", f"Access-Control-Allow-Origin={origin!r}"
    methods = (headers.get("Access-Control-Allow-Methods") or "").upper()
    assert "POST" in methods, f"Access-Control-Allow-Methods={methods!r}"
    allow_headers = (headers.get("Access-Control-Allow-Headers") or "")
    assert "content-type" in allow_headers.lower(), f"Allow-Headers={allow_headers!r}"


@check("base.ingest_responde_rapido", "POST /ingest contesta antes de preprocesar (§1)",
       mode="sandbox")
def _ingest_rapido(ctx: Ctx) -> None:
    # El operador en el campo no espera: el POST tiene que volver ya y el trabajo
    # pesado queda en el worker en hilo aparte. Corre en sandbox: escribe.
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("smoke/README.txt", "gate de humo; no son datos reales\n")
    started = time.monotonic()
    code, body, _ = ctx.post("/ingest", buf.getvalue(),
                             {"Content-Type": "application/zip",
                              "X-Geo-Filename": "smoke_gate.zip"})
    elapsed = time.monotonic() - started
    assert code in (200, 202), f"/ingest -> {code}: {body[:200]!r}"
    assert elapsed < 5.0, f"/ingest tardó {elapsed:.1f}s; debe responder antes de preprocesar"


# ── Checks refactor (§1: http.server -> FastAPI + estáticos) ──────────────────
@check("refactor.stack_fastapi", "GET /openapi.json expone /ingest y /api/dataset")
def _stack_fastapi(ctx: Ctx) -> None:
    data = ctx.json_get("/openapi.json")
    paths = data.get("paths", {})
    assert "/ingest" in paths, f"/ingest no está en openapi paths: {list(paths)}"
    assert "/api/dataset" in paths, f"/api/dataset no está en openapi paths: {list(paths)}"


@check("refactor.estaticos", "los estáticos se sirven desde /static")
def _estaticos(ctx: Ctx) -> None:
    code, body, headers = ctx.get("/static/css/app.css")
    assert code == 200, f"/static/css/app.css -> {code}"
    assert len(body) > 200, f"app.css muy chico: {len(body)} B"
    ctype = (headers.get("Content-Type") or "").lower()
    assert "css" in ctype, f"content-type de app.css={ctype!r}"
    for path in ("/static/js/main.js", "/static/js/theme.js", "/static/js/plot.js"):
        code, body, _ = ctx.get(path)
        assert code == 200, f"{path} -> {code}"
        assert len(body) > 100, f"{path} muy chico: {len(body)} B"


@check("refactor.index_sin_logica", "GET / es esqueleto: sin <style>/fetch/setInterval inline")
def _index_sin_logica(ctx: Ctx) -> None:
    code, body, _ = ctx.get("/")
    assert code == 200, f"/ -> {code}"
    text = body.decode("utf-8", "replace")
    assert "/static/js/main.js" in text, "/ no referencia /static/js/main.js"
    assert "/static/css/app.css" in text, "/ no referencia /static/css/app.css"
    assert "fetch(" not in text, "/ todavía tiene fetch( inline"
    assert "setInterval(" not in text, "/ todavía tiene setInterval( inline"
    assert "<style" not in text, "/ todavía tiene <style inline"


@check("refactor.tabs_presentes", "GET / trae los 8 nombres de tab literales")
def _tabs_presentes(ctx: Ctx) -> None:
    code, body, _ = ctx.get("/")
    assert code == 200, f"/ -> {code}"
    text = body.decode("utf-8", "replace")
    for nombre in ("Capturas", "Filtros", "Agrupamiento", "Enfase",
                   "Promedios / arrivals", "Waterfall", "MASW", "Borrado"):
        assert nombre in text, f"falta el tab {nombre!r} en /"


@check("refactor.contrato_dataset", "GET /api/dataset conserva el contrato JSON del port")
def _contrato_dataset(ctx: Ctx) -> None:
    data = ctx.json_get("/api/dataset")
    for key in ("raw_root", "folders", "capture_count", "node_count",
                "shot_count", "reviewed_count"):
        assert key in data, f"falta la clave {key!r} en /api/dataset"
    folders_con_capturas = [f for f in data["folders"] if f.get("captures")]
    assert folders_con_capturas, "ninguna carpeta con capturas en /api/dataset"
    cap = folders_con_capturas[0]["captures"][0]
    for key in ("capture", "order", "fs", "nodes", "has_hammer", "has_geo", "pickable"):
        assert key in cap, f"falta la clave {key!r} en una captura de /api/dataset"
    assert "pick" in cap, "falta la clave 'pick' (puede ser null) en una captura"


@check("refactor.raw_root_del_flag", "el raw_root reportado es el que pasó --raw-root")
def _raw_root_del_flag(ctx: Ctx) -> None:
    data = ctx.json_get("/api/dataset")
    reportado = Path(data["raw_root"]).resolve()
    esperado = ctx.raw_root.resolve()
    assert reportado == esperado, f"raw_root reportado {reportado} != esperado {esperado}"


@check("refactor.cors_en_post", "POST /ingest con Origin trae Access-Control-Allow-Origin: *",
       mode="sandbox")
def _cors_en_post(ctx: Ctx) -> None:
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("smoke/README.txt", "gate de humo; no son datos reales\n")
    code, body, headers = ctx.post(
        "/ingest", buf.getvalue(),
        {"Content-Type": "application/zip",
         "X-Geo-Filename": "smoke_cors.zip",
         "Origin": "http://192.168.4.1"})
    assert code in (200, 202), f"/ingest -> {code}: {body[:200]!r}"
    origin = headers.get("Access-Control-Allow-Origin")
    assert origin == "*", f"Access-Control-Allow-Origin={origin!r}"


@check("refactor.worker_no_bloquea", "el preprocesado corre en hilo aparte, no en el event loop",
       mode="sandbox")
def _worker_no_bloquea(ctx: Ctx) -> None:
    import io
    import zipfile

    def zip_bytes(i: int) -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr(f"smoke/README_{i}.txt", "gate de humo; no son datos reales\n")
        return buf.getvalue()

    for i in range(3):
        code, body, _ = ctx.post("/ingest", zip_bytes(i),
                                 {"Content-Type": "application/zip",
                                  "X-Geo-Filename": f"smoke_worker_{i}.zip"})
        assert code in (200, 202), f"/ingest #{i} -> {code}: {body[:200]!r}"

    started = time.monotonic()
    code, _, _ = ctx.get("/health")
    assert code == 200, f"/health -> {code}"
    elapsed_health = time.monotonic() - started
    assert elapsed_health < 2.0, f"/health tardó {elapsed_health:.1f}s"

    started = time.monotonic()
    jobs = ctx.json_get("/api/jobs")
    elapsed_jobs = time.monotonic() - started
    assert elapsed_jobs < 2.0, f"/api/jobs tardó {elapsed_jobs:.1f}s"
    assert len(jobs.get("jobs", [])) >= 3, f"/api/jobs listó {len(jobs.get('jobs', []))} < 3"


# ── Checks tabs (§2: tabs de navegación + toggle de tema) ─────────────────────
def _index_text(ctx: Ctx) -> str:
    code, body, _ = ctx.get("/")
    assert code == 200, f"/ -> {code}"
    return body.decode("utf-8", "replace")


TAB_NAMES = ("Capturas", "Filtros", "Agrupamiento", "Enfase",
             "Promedios / arrivals", "Waterfall", "MASW", "Borrado")

MASW_SUBTABS = (
    ("1. Dispersion", "dispersion"),
    ("2. Inversion", "inversion"),
    ("3. Perfil Vs", "perfil"),
)

PANELES_PENDIENTES = (
    "filtros", "agrupamiento", "enfase", "promedios", "waterfall",
    "subpanel-dispersion", "subpanel-inversion", "subpanel-perfil",
)


@check("tabs.nombres_y_orden", "los 8 tabs de la app aparecen en / en el orden exacto")
def _tabs_nombres_y_orden(ctx: Ctx) -> None:
    text = _index_text(ctx)
    positions = []
    for nombre in TAB_NAMES:
        # Bordes de letra: si no, "Waterfall" matchea dentro de "Waterfalll".
        m = re.search(r'(?<![A-Za-z])' + re.escape(nombre) + r'(?![A-Za-z])', text)
        assert m, f"falta el tab {nombre!r} en /"
        positions.append(m.start())
    for a, b, nombre_a, nombre_b in zip(positions, positions[1:], TAB_NAMES, TAB_NAMES[1:]):
        assert a < b, f"orden de tabs roto: {nombre_a!r} debería ir antes que {nombre_b!r}"
    count = text.count('data-tab="')
    assert count == 8, f'se esperaban 8 data-tab="..." y hay {count}'


@check("tabs.masw_subtabs", "las 3 subtabs de MASW están en / con sus data-subtab e id")
def _tabs_masw_subtabs(ctx: Ctx) -> None:
    text = _index_text(ctx)
    for nombre, subtab in MASW_SUBTABS:
        assert nombre in text, f"falta la subtab {nombre!r} en /"
        assert f'data-subtab="{subtab}"' in text, f'falta data-subtab="{subtab}" en /'
        assert f'id="subpanel-{subtab}"' in text, f'falta id="subpanel-{subtab}" en /'


@check("tabs.panel_por_tab", "cada data-tab tiene su panel-<X> y no hay paneles huérfanos")
def _tabs_panel_por_tab(ctx: Ctx) -> None:
    text = _index_text(ctx)
    tabs = re.findall(r'data-tab="([a-z]+)"', text)
    assert tabs, "no se encontró ningún data-tab en /"
    for name in tabs:
        assert f'id="panel-{name}"' in text, (
            f'el botón data-tab="{name}" no tiene su id="panel-{name}"')
    panels = re.findall(r'id="panel-([a-z]+)"', text)
    for name in panels:
        assert f'data-tab="{name}"' in text, (
            f'panel-{name} no tiene ningún botón data-tab="{name}" (panel huérfano)')


@check("tabs.placeholders_honestos", "los paneles pendientes dicen qué falta y dónde está escrito")
def _tabs_placeholders_honestos(ctx: Ctx) -> None:
    text = _index_text(ctx)
    # Límites de bloque: el próximo id="panel-..." o id="subpanel-..." (o fin de
    # documento). Nunca se confunden entre sí: "subpanel-" no contiene la
    # subcadena literal 'id="panel-'.
    markers = [(m.start(), m.group(1))
               for m in re.finditer(r'id="((?:sub)?panel-[a-z]+)"', text)]
    for target in PANELES_PENDIENTES:
        marker_id = target if target.startswith("subpanel-") else f"panel-{target}"
        starts = [pos for pos, name in markers if name == marker_id]
        assert starts, f'no se encontró id="{marker_id}" en /'
        start = starts[0]
        later = [pos for pos, _ in markers if pos > start]
        end = min(later) if later else len(text)
        block = text[start:end]
        assert "Falta:" in block, f'{marker_id}: falta el literal "Falta:" en su placeholder'
        assert "§" in block, f'{marker_id}: falta la referencia "§" al PORT_PLAN'
        assert len(block) >= 120, f'{marker_id}: placeholder de {len(block)} caracteres (< 120)'


@check("tabs.tema_toggle", "el botón de tema y las reglas [data-theme] de los dos temas existen")
def _tabs_tema_toggle(ctx: Ctx) -> None:
    text = _index_text(ctx)
    assert 'id="btn-theme"' in text, 'falta id="btn-theme" en /'

    code, body, _ = ctx.get("/static/js/theme.js")
    assert code == 200, f"/static/js/theme.js -> {code}"
    theme_js = body.decode("utf-8", "replace")
    for token in ("localStorage", "data-theme", "prefers-color-scheme"):
        assert token in theme_js, f"theme.js no contiene {token!r}"

    code, body, _ = ctx.get("/static/css/app.css")
    assert code == 200, f"/static/css/app.css -> {code}"
    css = body.decode("utf-8", "replace")
    assert '[data-theme="dark"]' in css, 'app.css no define [data-theme="dark"]'
    assert '[data-theme="light"]' in css, 'app.css no define [data-theme="light"]'


@check("tabs.tema_sin_flash", "theme-boot.js corre en <head> como script clásico, misma clave que theme.js")
def _tabs_tema_sin_flash(ctx: Ctx) -> None:
    text = _index_text(ctx)
    head_end = text.find("</head>")
    assert head_end >= 0, "/ no tiene </head>"
    boot_pos = text.find("/static/js/theme-boot.js")
    assert boot_pos >= 0, "/ no referencia /static/js/theme-boot.js"
    assert boot_pos < head_end, "theme-boot.js debe estar antes de </head>"

    tag_start = text.rfind("<script", 0, boot_pos)
    tag_end = text.find(">", boot_pos)
    tag = text[tag_start:tag_end + 1]
    assert 'type="module"' not in tag, "theme-boot.js no puede ser type=module (corre diferido)"
    assert "defer" not in tag, "theme-boot.js no puede ser defer (corre diferido)"

    code, body, _ = ctx.get("/static/js/theme-boot.js")
    assert code == 200, f"/static/js/theme-boot.js -> {code}"
    boot_js = body.decode("utf-8", "replace")

    code, body, _ = ctx.get("/static/js/theme.js")
    assert code == 200, f"/static/js/theme.js -> {code}"
    theme_js = body.decode("utf-8", "replace")

    m = re.search(r"localStorage\.getItem\('([^']+)'\)", boot_js)
    assert m, "theme-boot.js no lee localStorage.getItem('...')"
    key_boot = m.group(1)
    assert key_boot in theme_js, (
        f"la clave {key_boot!r} de theme-boot.js no aparece igual en theme.js")


# ── Checks capturas/señal (§3.1: GET /api/signal + dibujo) ────────────────────
def _first_shot(ctx: Ctx) -> tuple[str, dict]:
    """Primer (shot_id, captura) del dataset real que se pueda dibujar.

    Filtra por pick.shot_id y NO por pickable: son distintos (spec §5.1 —
    catalog.py deduce el rol sólo de node["role"], frd._node_role mira además
    type/hw_type/name/data_dir/raw_file, y 194 shots != 186 pickable).
    """
    data = ctx.json_get("/api/dataset")
    for folder in data.get("folders", []):
        for cap in folder.get("captures", []):
            pick = cap.get("pick") or {}
            if pick.get("shot_id"):
                return pick["shot_id"], cap
    raise AssertionError("ninguna captura de /api/dataset trae pick.shot_id: "
                         "sin eso la web no puede dibujar nada")


def _write_fixture(ctx: Ctx, folder: str, *, spike: float, with_nan: bool) -> str:
    """Escribe una captura sintética en el raw_root del SANDBOX y devuelve su shot_id.

    Cinturón de seguridad: nunca contra el dataset real (regla 2 del prompt).
    Se escribe directo a disco (no por /ingest) para no correr auto_pick_shot +
    save_annotations sobre el archivo de picks real (§8.1 del spec: el sandbox
    y el dataset real comparten el mismo default_annotations_path por nombre
    de carpeta). El shot_id se obtiene por HTTP (/api/dataset), no reimportando
    field_review_data acá: el gate sigue hablando sólo HTTP.
    """
    assert ctx.sandbox and "smoke_sandbox" in str(ctx.raw_root), \
        f"_write_fixture sólo va en sandbox; raw_root={ctx.raw_root}"
    import numpy as np

    cap_dir = ctx.raw_root / folder / "captures" / "001_smoke"
    hammer_dir = cap_dir / "hammer_s1"
    geo_dir = cap_dir / "geo1_s2"
    hammer_dir.mkdir(parents=True, exist_ok=True)
    geo_dir.mkdir(parents=True, exist_ok=True)

    meta = {
        "order": 1, "fs": 1000,
        "nodes": [
            {"index": 1, "pcb_id": "S1", "role": "hammer", "type": "Hammer", "fs": 1000,
             "data_dir": "captures/001_smoke/hammer_s1",
             "raw_file": "captures/001_smoke/hammer_s1/raw_f32le.bin"},
            {"index": 2, "pcb_id": "S2", "role": "geo", "type": "Geo", "fs": 1000,
             "position_m": 4.0, "data_dir": "captures/001_smoke/geo1_s2",
             "raw_file": "captures/001_smoke/geo1_s2/raw_f32le.bin"},
        ],
    }
    (cap_dir / "metadata.json").write_text(json.dumps(meta), encoding="utf-8")

    # Pico +spike en la muestra 1000 (5 muestras, salto abrupto sobre línea de
    # base plana) para que detect_hammer_trigger lo tome. Cada fixture con
    # contenido distinto (spike distinto): dos carpetas byte-idénticas quedan
    # marcadas duplicadas por discover_dataset y la segunda pierde su shot.
    n = 4000
    hammer = np.zeros(n, dtype=np.float32)
    hammer[998:1003] = np.float32(spike)
    geo = np.zeros(n, dtype=np.float32)
    geo[998:1003] = np.float32(spike)
    if with_nan:
        geo[3000:3003] = np.nan
    hammer.tofile(hammer_dir / "raw_f32le.bin")
    geo.tofile(geo_dir / "raw_f32le.bin")

    data = ctx.json_get("/api/dataset")
    for f in data.get("folders", []):
        if f["folder"] != folder:
            continue
        for cap in f.get("captures", []):
            if cap["capture"] == "001_smoke":
                shot_id = (cap.get("pick") or {}).get("shot_id")
                assert shot_id, f"fixture {folder}/001_smoke sin shot_id en /api/dataset: {cap}"
                return shot_id
    raise AssertionError(f"fixture {folder}/001_smoke no aparece en /api/dataset tras escribirla")


@check("capturas.signal.contrato", "GET /api/signal trae todas las claves del contrato (spec §4.2)")
def _signal_contrato(ctx: Ctx) -> None:
    shot_id, _cap = _first_shot(ctx)
    data = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=500")
    for key in ("shot_id", "folder", "capture", "fs", "kind", "max_points",
                "trigger_s", "trigger_source", "geo_flip", "channels"):
        assert key in data, f"falta la clave {key!r} en /api/signal: {sorted(data)}"
    channels = data["channels"]
    assert "hammer" in channels and "geo" in channels, f"channels={sorted(channels)}"
    assert data["fs"] > 0, f"fs={data['fs']}"
    for role, ch in channels.items():
        for key in ("role", "pcb_id", "file", "used_filtered", "invert_applied",
                    "flip_applied", "samples", "duration_s", "stride", "buckets",
                    "bucket_dt", "decimated", "y_min", "y_max", "min", "max"):
            assert key in ch, f"falta la clave {key!r} en channels.{role}: {sorted(ch)}"
        assert "t" not in ch, f"channels.{role} manda 't': el eje se deriva, no se manda (§4.2.3)"
        assert ch["samples"] > 0, f"channels.{role}.samples={ch['samples']}"
        assert len(ch["min"]) == len(ch["max"]) == ch["buckets"], (
            f"channels.{role}: len(min)={len(ch['min'])} len(max)={len(ch['max'])} "
            f"buckets={ch['buckets']}")
        assert ch["buckets"] <= 500, f"channels.{role}.buckets={ch['buckets']} > max_points=500"
        assert ch["decimated"] is True, (
            f"channels.{role}.decimated={ch['decimated']}, con max_points=500 y "
            f"samples={ch['samples']} tiene que decimar")
        assert ch["bucket_dt"] > 0, f"channels.{role}.bucket_dt={ch['bucket_dt']}"
        assert ":" not in ch["file"] and "\\" not in ch["file"], (
            f"channels.{role}.file no es relativo con '/': {ch['file']!r}")


@check("capturas.signal.decimado_conserva_picos", "min/max conserva los extremos exactos de la señal cruda")
def _signal_decimado(ctx: Ctx) -> None:
    shot_id, _cap = _first_shot(ctx)
    dec = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=500")
    raw = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=100000")
    for role in ("hammer", "geo"):
        chd = dec["channels"][role]
        chr_ = raw["channels"][role]
        assert chr_["stride"] == 1, (
            f"{role}: stride={chr_['stride']} con max_points=100000, se esperaba 1 (crudo)")
        assert chr_["decimated"] is False, f"{role}: decimated={chr_['decimated']} con stride==1"
        assert chr_["min"] == chr_["max"], f"{role}: con stride==1 min y max tienen que ser iguales"
        assert chd["buckets"] <= 500 < chr_["samples"], (
            f"{role}: buckets={chd['buckets']} samples={chr_['samples']}")

        raw_maxs = [v for v in chr_["max"] if v is not None]
        raw_mins = [v for v in chr_["min"] if v is not None]
        dec_maxs = [v for v in chd["max"] if v is not None]
        dec_mins = [v for v in chd["min"] if v is not None]
        assert raw_maxs and raw_mins and dec_maxs and dec_mins, f"{role}: buckets vacíos"

        max_dec, max_raw = max(dec_maxs), max(raw_maxs)
        min_dec, min_raw = min(dec_mins), min(raw_mins)
        assert math.isclose(max_dec, max_raw, rel_tol=1e-5), (
            f"{role}: max(max_decimado)={max_dec} != max(max_crudo)={max_raw} "
            f"(un decimado que promedia o saltea se come el pico)")
        assert math.isclose(min_dec, min_raw, rel_tol=1e-5), (
            f"{role}: min(min_decimado)={min_dec} != min(min_crudo)={min_raw}")

    body_size = len(json.dumps(dec).encode("utf-8"))
    assert body_size < 60_000, f"cuerpo del decimado (max_points=500) pesa {body_size} B >= 60 kB"


@check("capturas.signal.max_points_clamp", "max_points se clampea a [100,20000], no se rechaza ni explota")
def _signal_clamp(ctx: Ctx) -> None:
    shot_id, _cap = _first_shot(ctx)

    data = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=1")
    buckets = data["channels"]["hammer"]["buckets"]
    assert buckets >= 100, f"max_points=1: buckets={buckets} < 100 (mínimo del clamp)"

    data = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=1000000000")
    buckets = data["channels"]["hammer"]["buckets"]
    assert buckets <= 20000, f"max_points=1e9: buckets={buckets} > 20000 (máximo del clamp)"

    code, body, _ = ctx.get(f"/api/signal?shot_id={shot_id}&max_points=abc")
    assert code == 422, f"max_points=abc -> {code} (se esperaba 422, no 400 ni 500): {body[:200]!r}"


@check("capturas.signal.sin_nan_en_json", "el JSON no lleva literales NaN/Infinity (no son JSON válido)")
def _signal_sin_nan(ctx: Ctx) -> None:
    shot_id, _cap = _first_shot(ctx)
    code, body, _ = ctx.get(f"/api/signal?shot_id={shot_id}&max_points=2000")
    assert code == 200, f"/api/signal -> {code}: {body[:200]!r}"
    assert b"NaN" not in body, "el cuerpo crudo contiene el literal NaN (JSON.parse falla en el navegador)"
    assert b"Infinity" not in body, "el cuerpo crudo contiene el literal Infinity"

    def _no_constants(name):
        raise AssertionError(f"json.loads encontró la constante no-JSON {name!r} en el cuerpo")

    json.loads(body.decode("utf-8", "replace"), parse_constant=_no_constants)


@check("capturas.signal.kind_filt", "kind distingue raw_f32le.bin de filt_f32le.bin; kind inválido -> 400")
def _signal_kind(ctx: Ctx) -> None:
    shot_id, _cap = _first_shot(ctx)

    data = ctx.json_get(f"/api/signal?shot_id={shot_id}&kind=filt&max_points=500")
    for role, ch in data["channels"].items():
        assert ch["used_filtered"] is True, f"{role}: used_filtered={ch['used_filtered']} con kind=filt"
        assert ch["file"].endswith("filt_f32le.bin"), (
            f"{role}: file={ch['file']!r} no termina en filt_f32le.bin")

    data = ctx.json_get(f"/api/signal?shot_id={shot_id}&kind=raw&max_points=500")
    for role, ch in data["channels"].items():
        assert ch["used_filtered"] is False, f"{role}: used_filtered={ch['used_filtered']} con kind=raw"
        assert ch["file"].endswith("raw_f32le.bin"), (
            f"{role}: file={ch['file']!r} no termina en raw_f32le.bin")

    code, body, _ = ctx.get(f"/api/signal?shot_id={shot_id}&kind=xxx&max_points=500")
    assert code == 400, f"kind=xxx -> {code} (se esperaba 400): {body[:200]!r}"


@check("capturas.signal.shot_desconocido", "shot_id inexistente -> 404; shot_id vacío -> 400/422, nunca 200/500")
def _signal_desconocido(ctx: Ctx) -> None:
    code, body, _ = ctx.get("/api/signal?shot_id=0000000000000000&max_points=500")
    assert code == 404, f"shot_id inexistente -> {code} (se esperaba 404): {body[:200]!r}"

    code, body, _ = ctx.get("/api/signal?shot_id=&max_points=500")
    assert code in (400, 422), f"shot_id vacío -> {code} (se esperaba 400 o 422): {body[:200]!r}"


@check("capturas.signal.trigger_marcado", "trigger_s sale de la anotación o de auto_pick_shot, nunca inventado")
def _signal_trigger(ctx: Ctx) -> None:
    shot_id, cap = _first_shot(ctx)
    data = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=500")
    trigger_s = data["trigger_s"]
    duration_s = data["channels"]["hammer"]["duration_s"]
    assert trigger_s is not None and math.isfinite(trigger_s), f"trigger_s={trigger_s} no finito"
    assert 0 <= trigger_s <= duration_s, f"trigger_s={trigger_s} fuera de [0, {duration_s}]"
    assert data["trigger_source"] in ("annotation", "auto"), f"trigger_source={data['trigger_source']!r}"

    pick_trigger = (cap.get("pick") or {}).get("trigger_s")
    if pick_trigger is not None:
        assert data["trigger_source"] == "annotation", (
            f"/api/dataset trae pick.trigger_s={pick_trigger} pero /api/signal dice "
            f"trigger_source={data['trigger_source']!r}")
        assert abs(data["trigger_s"] - pick_trigger) < 1e-9, (
            f"trigger_s difiere: /api/signal={data['trigger_s']} /api/dataset={pick_trigger}")
    else:
        assert data["trigger_source"] == "auto", (
            f"/api/dataset no trae pick.trigger_s pero /api/signal dice "
            f"trigger_source={data['trigger_source']!r}")


@check("capturas.signal.no_bloquea", "GET /api/signal no bloquea el event loop (handler síncrono, spec §4.6)")
def _signal_no_bloquea(ctx: Ctx) -> None:
    from concurrent.futures import ThreadPoolExecutor

    shot_id, _cap = _first_shot(ctx)
    with ThreadPoolExecutor(max_workers=3) as pool:
        futs = [pool.submit(ctx.get, f"/api/signal?shot_id={shot_id}&max_points=2000&_r={i}")
               for i in range(3)]

        started = time.monotonic()
        code, _, _ = ctx.get("/health")
        elapsed_health = time.monotonic() - started
        assert code == 200, f"/health -> {code}"
        assert elapsed_health < 2.0, (
            f"/health tardó {elapsed_health:.1f}s mientras /api/signal corría en paralelo: "
            f"¿el handler quedó async def con trabajo bloqueante adentro? (spec §4.6)")

        started = time.monotonic()
        ctx.json_get("/api/jobs")
        elapsed_jobs = time.monotonic() - started
        assert elapsed_jobs < 2.0, f"/api/jobs tardó {elapsed_jobs:.1f}s"

        for i, fut in enumerate(futs):
            code, body, _ = fut.result(timeout=30)
            assert code == 200, f"/api/signal #{i} -> {code}: {body[:200]!r}"


@check("capturas.signal.ui_usa_endpoint", "el JS del visor usa /api/signal y está enganchado a la tabla")
def _signal_ui(ctx: Ctx) -> None:
    code, body, _ = ctx.get("/static/js/tabs/capturas_signal.js")
    assert code == 200, f"/static/js/tabs/capturas_signal.js -> {code}"
    js = body.decode("utf-8", "replace")
    for token in ("/api/signal", "max_points", "geo_flip"):
        assert token in js, f"capturas_signal.js no contiene {token!r}"

    code, body, _ = ctx.get("/static/js/plot.js")
    assert code == 200, f"/static/js/plot.js -> {code}"
    assert "export function drawMinMax" in body.decode("utf-8", "replace"), (
        "plot.js no exporta drawMinMax")

    code, body, _ = ctx.get("/static/js/tabs/capturas.js")
    assert code == 200, f"/static/js/tabs/capturas.js -> {code}"
    caps_js = body.decode("utf-8", "replace")
    assert "capturas_signal.js" in caps_js, "capturas.js no importa capturas_signal.js"
    assert "shot_id" in caps_js, "capturas.js no usa shot_id para habilitar el botón ver"


@check("capturas.signal.polaridad_fija", "convención fija: hammer sale invertido, geo no (fixture sintética)",
      mode="sandbox")
def _signal_polaridad(ctx: Ctx) -> None:
    shot_id = _write_fixture(ctx, "smoke_polaridad", spike=1.0, with_nan=False)
    data = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=100000")
    hammer = data["channels"]["hammer"]
    geo = data["channels"]["geo"]

    h_min = min(v for v in hammer["min"] if v is not None)
    h_max = max(v for v in hammer["max"] if v is not None)
    g_min = min(v for v in geo["min"] if v is not None)
    g_max = max(v for v in geo["max"] if v is not None)
    assert h_min <= -0.9, f"hammer: min={h_min}, se esperaba <= -0.9 (invertido)"
    assert h_max <= 0.1, f"hammer: max={h_max}, se esperaba <= 0.1 (invertido, no queda el +spike)"
    assert g_max >= 0.9, f"geo: max={g_max}, se esperaba >= 0.9 (no invertido)"
    assert g_min >= -0.1, f"geo: min={g_min}, se esperaba >= -0.1 (no invertido)"

    assert hammer["invert_applied"] is True, f"hammer.invert_applied={hammer['invert_applied']}"
    assert geo["invert_applied"] is False, f"geo.invert_applied={geo['invert_applied']}"
    assert hammer["flip_applied"] is False, f"hammer.flip_applied={hammer['flip_applied']}"
    assert geo["flip_applied"] is False, f"geo.flip_applied={geo['flip_applied']}"

    # La fixture tiene el golpe en la muestra 998-1002 de 4000 a fs=1000, así
    # que auto_pick_shot (onset: una muestra antes del flanco) tiene que dar
    # trigger_s ~= 0.997. Un trigger fuera de [0.9, 1.1] está inventado (p.ej.
    # trigger_s=0.0 fijo), no sale de auto_pick_shot: revisión del intento 1.
    assert 0.9 <= data["trigger_s"] <= 1.1, (
        f"trigger_s={data['trigger_s']}: la fixture tiene el golpe en la muestra "
        f"1000 de 4000 a fs=1000, o sea ~0.997 s. Un trigger fuera de [0.9, 1.1] "
        f"está inventado, no sale de auto_pick_shot")
    assert data["trigger_source"] == "auto", (
        f"trigger_source={data['trigger_source']!r}, se esperaba 'auto' (la fixture "
        f"no tiene anotación). NOTA: la rama trigger_source=='annotation' no tiene "
        f"cobertura en este ítem porque hoy reviewed_count==0 y este ítem no puede "
        f"escribir anotaciones (spec §8.1) — queda declarado, no tapado.")


@check("capturas.signal.nan_a_null", "NaN de la señal se convierte a null, nunca a 0.0 ni pasa crudo",
      mode="sandbox")
def _signal_nan(ctx: Ctx) -> None:
    shot_id = _write_fixture(ctx, "smoke_nan", spike=0.8, with_nan=True)
    code, body, _ = ctx.get(f"/api/signal?shot_id={shot_id}&max_points=100000")
    assert code == 200, f"/api/signal -> {code}: {body[:200]!r}"
    assert b"NaN" not in body, "el cuerpo crudo contiene el literal NaN"

    data = json.loads(body.decode("utf-8", "replace"))
    geo = data["channels"]["geo"]
    assert geo["stride"] == 1, f"geo.stride={geo['stride']}, se esperaba 1 (max_points alto)"
    assert None in geo["min"], "geo.min no tiene ningún null: el NaN de la fixture no se convirtió"
    assert None in geo["max"], "geo.max no tiene ningún null: el NaN de la fixture no se convirtió"
    numeric = [v for v in geo["min"] if v is not None]
    assert numeric, "geo.min no tiene ningún bucket con dato real (además de los null)"


@check("capturas.signal.geo_flip_override", "geo_flip=1 invierte sólo el geo, en preview, sin tocar el hammer",
      mode="sandbox")
def _signal_geo_flip(ctx: Ctx) -> None:
    shot_id = _write_fixture(ctx, "smoke_polaridad", spike=1.0, with_nan=False)

    base = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=100000")
    flipped = ctx.json_get(f"/api/signal?shot_id={shot_id}&max_points=100000&geo_flip=1")

    g0, g1 = base["channels"]["geo"], flipped["channels"]["geo"]
    g0_max = max(v for v in g0["max"] if v is not None)
    g1_min = min(v for v in g1["min"] if v is not None)
    g1_max = max(v for v in g1["max"] if v is not None)
    assert g0_max >= 0.9, f"sin geo_flip: geo.max={g0_max}, se esperaba >= 0.9"
    assert g0["flip_applied"] is False, f"sin geo_flip: geo.flip_applied={g0['flip_applied']}"
    assert g1_min <= -0.9, f"con geo_flip=1: geo.min={g1_min}, se esperaba <= -0.9"
    assert g1_max <= 0.1, f"con geo_flip=1: geo.max={g1_max}, se esperaba <= 0.1"
    assert g1["flip_applied"] is True, f"con geo_flip=1: geo.flip_applied={g1['flip_applied']}"

    h0, h1 = base["channels"]["hammer"], flipped["channels"]["hammer"]
    assert h0["min"] == h1["min"] and h0["max"] == h1["max"], (
        "el hammer cambió entre las dos respuestas: geo_flip no tiene que tocarlo")


# ── Arranque del servidor bajo prueba ─────────────────────────────────────────
def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@dataclass
class Server:
    proc: subprocess.Popen
    port: int
    tmp: Path | None = None
    log_path: Path | None = None

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def log_tail(self, lines: int = 40) -> str:
        if not self.log_path or not self.log_path.is_file():
            return "(sin log del servidor)"
        text = self.log_path.read_text(encoding="utf-8", errors="replace")
        return "\n".join(text.splitlines()[-lines:]) or "(log vacío)"

    def stop(self) -> None:
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
        if self.tmp and self.tmp.exists():
            shutil.rmtree(self.tmp, ignore_errors=True)


def start_server(raw_root: Path, data_root: Path, tmp: Path | None,
                 log_path: Path, boot_timeout_s: float = 60.0) -> Server | None:
    """Arranca el servidor bajo prueba con su salida A UN ARCHIVO.

    Nunca a subprocess.PIPE sin leerlo: el buffer del pipe son ~64 kB y cuando se
    llena el servidor se **bloquea escribiendo**, así que las requests empiezan a
    colgarse. Pasó de verdad: `refactor.worker_no_bloquea` daba timeout a los 30 s
    en tanda y pasaba en 0.1 s aislado, y el bug era del gate, no del servidor.
    Además el archivo es el log que hace falta para no adivinar.
    """
    port = free_port()
    cmd = [sys.executable, "-m", "server", "--port", str(port),
           "--raw-root", str(raw_root), "--data-root", str(data_root)]
    log_path.parent.mkdir(parents=True, exist_ok=True)
    handle = log_path.open("w", encoding="utf-8", errors="replace")
    proc = subprocess.Popen(cmd, cwd=str(PYTHON_ROOT), stdout=handle,
                            stderr=subprocess.STDOUT, text=True)
    srv = Server(proc, port, tmp, log_path)
    rec(f"servidor pid={proc.pid} puerto={port} raw={raw_root}", echo=True)
    rec(f"  intérprete={sys.executable}")
    rec(f"  log del servidor -> {log_path}", echo=True)
    deadline = time.time() + boot_timeout_s
    while time.time() < deadline:
        if proc.poll() is not None:
            rec(f"el servidor murió al arrancar (rc={proc.returncode}):\n"
                f"{srv.log_tail()}", echo=True)
            return None
        try:
            with urllib.request.urlopen(f"{srv.base_url}/health", timeout=2) as r:
                if r.status == 200:
                    rec(f"  arrancó en {time.time() - (deadline - boot_timeout_s):.1f}s")
                    return srv
        except Exception:
            time.sleep(0.4)
    rec(f"el servidor no respondió /health en {boot_timeout_s:.0f}s:\n"
        f"{srv.log_tail()}", echo=True)
    srv.stop()
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--only", action="append", default=[],
                    help="correr sólo los checks cuyo id empieza así (repetible)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--json", help="escribir el reporte a este archivo")
    ap.add_argument("--raw-root", default=str(RAW_ROOT))
    ap.add_argument("--require", action="append", default=[],
                    help="exigir que exista al menos un check con este prefijo; "
                         "si no, fallar. Evita el gate verde falso de un ítem "
                         "que no agregó ni un check propio.")
    ap.add_argument("--log-dir", default=str(LOG_DIR),
                    help="dónde dejar el log de la corrida y el del servidor")
    args = ap.parse_args()

    if args.list:
        for c in REGISTRY:
            print(f"{c.cid:34s} [{c.mode:7s}] {c.desc}")
        return 0

    selected = [c for c in REGISTRY
                if not args.only or any(c.cid.startswith(p) for p in args.only)]
    if not selected:
        print(f"ningún check coincide con {args.only}", file=sys.stderr)
        return 2

    for prefix in args.require:
        if not any(c.cid.startswith(prefix) for c in REGISTRY):
            print(f"[gate] FALLA: no existe ningún check con prefijo {prefix!r}. "
                  f"El ítem tiene que aportar sus propios checks; pasar sólo los "
                  f"checks base es un verde falso.", file=sys.stderr)
            return 1

    raw_root = Path(args.raw_root)
    if not raw_root.is_dir():
        print(f"no existe raw_root {raw_root}", file=sys.stderr)
        return 2

    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    run_log = log_dir / f"gate_{stamp}.log"
    rec(f"gate {stamp} — checks: {[c.cid for c in selected]}")
    rec(f"  raw_root={raw_root}")
    rec(f"  intérprete={sys.executable}  cwd={Path.cwd()}")

    results: list[dict] = []
    for mode in ("read", "sandbox"):
        batch = [c for c in selected if c.mode == mode]
        if not batch:
            continue
        srv_log = log_dir / f"gate_{stamp}_servidor_{mode}.log"
        if mode == "read":
            tmp = Path(tempfile.mkdtemp(prefix="smoke_data_"))
            srv = start_server(raw_root, tmp / "server", tmp, srv_log)
        else:
            tmp = Path(tempfile.mkdtemp(prefix="smoke_sandbox_"))
            (tmp / "raw").mkdir()
            srv = start_server(tmp / "raw", tmp / "server", tmp, srv_log)
        if srv is None:
            print(f"[gate] el servidor no arrancó (modo {mode}); "
                  f"por qué: {srv_log}", file=sys.stderr)
            shutil.rmtree(tmp, ignore_errors=True)
            run_log.write_text("\n".join(RUN_LOG) + "\n", encoding="utf-8")
            return 2
        ctx = Ctx(srv.base_url, raw_root if mode == "read" else tmp / "raw",
                  sandbox=(mode == "sandbox"))
        print(f"[gate] servidor {mode} en {srv.base_url} (raw={ctx.raw_root})")
        try:
            for c in batch:
                rec(f"CHECK {c.cid} ({c.mode}) — {c.desc}")
                started = time.monotonic()
                try:
                    c.fn(ctx)
                    ok, detail = True, ""
                except Exception as exc:
                    ok, detail = False, f"{type(exc).__name__}: {exc}"
                dt = time.monotonic() - started
                rec(f"  -> {'PASS' if ok else 'FAIL'} en {dt:.2f}s {detail}")
                if not ok:
                    # El log del servidor es lo que explica un timeout; sin esto
                    # había que adivinar de qué lado estaba el problema.
                    rec(f"  --- cola del log del servidor ---\n{srv.log_tail(25)}")
                print(f"  {'PASS' if ok else 'FAIL'}  {c.cid:32s} {dt:5.1f}s  "
                      f"{detail or c.desc}")
                results.append({"id": c.cid, "desc": c.desc, "mode": c.mode,
                                "ok": ok, "detail": detail, "seconds": round(dt, 2),
                                "log_servidor": str(srv_log)})
        finally:
            srv.stop()

    passed = sum(1 for r in results if r["ok"])
    rec(f"resultado: {passed}/{len(results)} checks OK")
    run_log.write_text("\n".join(RUN_LOG) + "\n", encoding="utf-8")
    print(f"\n[gate] {passed}/{len(results)} checks OK")
    print(f"[gate] log de la corrida: {run_log}")
    if passed != len(results):
        for r in results:
            if not r["ok"]:
                print(f"[gate] log del servidor de {r['id']}: {r['log_servidor']}")
    if args.json:
        Path(args.json).write_text(
            json.dumps({"passed": passed, "total": len(results),
                        "run_log": str(run_log), "checks": results},
                       indent=2, ensure_ascii=False), encoding="utf-8")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
